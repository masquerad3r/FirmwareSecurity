#!/bin/bash

# Testing with renode-test
renode-test STM32F4_Discovery.robot

# Testing with renode
touch uart_logs.txt
renode stm32f4_discovery.resc